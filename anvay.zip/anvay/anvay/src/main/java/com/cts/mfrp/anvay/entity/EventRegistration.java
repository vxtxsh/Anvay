package com.cts.mfrp.anvay.entity;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "event_registration")
public class EventRegistration {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int eventRegistrationId;

    @ManyToOne
    @JoinColumn(name="eventId")
    private Event event;

    @ManyToOne
    @JoinColumn(name="userId")
    private User user;

    @Column(name = "pointsEarned")
    private int points_earned;

    @Column(name = "registered_at")
    private Date registeredAt;
}
